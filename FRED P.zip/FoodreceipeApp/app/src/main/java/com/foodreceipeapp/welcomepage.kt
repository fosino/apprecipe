package com.myrecipeapp

import android.os.Bundle

class WelcomePage  {

    private fun  onCreate(savedInstanceState: Bundle?) {
        this.onCreate(savedInstanceState)
        setContentView(R.layout.splashscreen)
    }

    private fun setContentView(splashscreen: Int) {

    }
}