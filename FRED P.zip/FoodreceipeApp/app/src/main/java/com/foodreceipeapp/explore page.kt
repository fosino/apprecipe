package com.foodreceipeapp

class `explore page` {
}